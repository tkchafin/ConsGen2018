#! /usr/bin/perl

use warnings;
use strict;

# the input fasta file is declared using an argument on the command line
# If no fasta file is specified, the program will die and print the usage
my $usage = "\nUsage: $0 fasta-file\n\n";
$ARGV[0] or die $usage;

# Declare variables
my $fasta = shift @ARGV;
my @header;
my @seq;
my $seqcount = 0;

# Open the FASTA file
open( FASTA, $fasta ) or die "Can't open $fasta: $!\n";

# Parse the fasta file
while( my $line = <FASTA> ){
    chomp($line);
    if( $line =~ /^>/ ){
	push @header, $line;
	$seqcount++;
	next;
    }else{
	$seq[$seqcount-1] .= $line;
    }
}

# Write each individual sequence to a new FASTA file using the genbank accession number as the name
for( my $i=0; $i<@header; $i++ ){
    my @temp = split( /\|/, $header[$i] );
    my $out = "$temp[3].fasta";
    print "Now writing to ", $out, "\n";
    open( OUT, '>', $out ) or die "Can't open $fasta: $!\n";
    print OUT $header[$i], "\n", $seq[$i], "\n";
    close OUT;
}

# Print the total number of files that were written
print "\n", $seqcount, " files were written\n\n";

# close the FASTA file
close FASTA;

exit;
